from django.shortcuts import render, get_object_or_404
from .models import Equipment

# Create your views here.
def home(request):
    rentals = Equipment.objects
    return render(request, 'rentals/home.html', {'rentals':rentals})

def detail(request, equipment_id):
    equipment_detail = get_object_or_404(Equipment, pk=equipment_id)
    return render(request, 'rentals/detail.html', {'equipment':equipment_detail})
