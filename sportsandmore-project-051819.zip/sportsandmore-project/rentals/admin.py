from django.contrib import admin

# #Ian's imports
# from .models import Customer
# from .models import Order
# from .models import OrderDetail
# from .models import Employee
# from .models import Equipment
# from .models import Inventory
# from .models import Fee
#
# # Register your models here.
# admin.site.register(Customer)
# admin.site.register(Order)
# admin.site.register(OrderDetail)
# admin.site.register(Employee)
# admin.site.register(Equipment)
# admin.site.register(Inventory)
# admin.site.register(Fee)

# Davis's imports + Ian's (5/5)
from .models import customer
@admin.register(customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['customerid', 'firstname', 'lastname', 'phonenumber', 'email']

from .models import order
from .models import orderdetails
from .models import employee

from .models import Equipment
@admin.register(Equipment)
class EquipmentAdmin(admin.ModelAdmin):
    list_display = ['equipdescr', 'equipcategory', 'equipstatus']

from .models import inventory
from .models import fees

# Register your models here..
# admin.site.register(customer)
admin.site.register(order)
admin.site.register(orderdetails)
admin.site.register(employee)

# admin.site.register(Equipment)

admin.site.register(inventory)
admin.site.register(fees)
