from django.db import models
from datetime import datetime

# Davis's classes
class customer(models.Model):
    customerid = models.IntegerField('Customer ID', primary_key=True)
    firstname = models.CharField('First Name',max_length=100)
    lastname = models.CharField('Last Name',max_length=100)
    phonenumber = models.CharField('Phone',max_length=10)
    creditcard = models.CharField('Credit Card',max_length=16)
    email = models.CharField('Email',max_length=100)
    createddate = models.DateTimeField('Date Added', default = datetime.now)

    def __str__(self):
        return ('%s, %s' % (self.lastname, self.firstname))

    # this will name the table appropirately in the db
    class Meta:
        db_table = 'customer'

class employee(models.Model):
    employeeid = models.IntegerField(primary_key=True)
    firstname = models.CharField('First Name',max_length=100)
    lastname = models.CharField('Last Name',max_length=100)
    title = models.CharField('Title',max_length=100)
    reportsto = models.CharField('Reports To',max_length=100)
    createddate = models.DateTimeField(default = datetime.now)

	# this will name the table appropirately in the db
    class Meta:
        db_table = 'employee'

class Equipment(models.Model):
    available = 'AV'
    checkedout = 'CO'
    inservice = 'SV'

    equip_status_choices = (
    (available, 'Available'),
    (checkedout, 'Checked Out'),
    (inservice, 'In Service'),
    )

    equipmentid = models.IntegerField('Serial Number', primary_key=True)
    equipimage = models.ImageField('Image', upload_to='images/')
    equipdescr = models.CharField('Item', max_length=500)
    equiptext = models.CharField('Description', max_length=1000, null=True)
    equipcategory =  models.CharField('Category', max_length=100)
    equippriceday = models.IntegerField('Price/day', default=0)
    equippriceweek = models.IntegerField('Price/week', default=0)
    equippricemonth = models.IntegerField('Price/month', default=0)
    createdate = models.DateTimeField('Date Added')
    equipstatus = models.CharField(
    'Status',
    max_length=50,
    choices=equip_status_choices,
    default='Available',
    blank=False,
    null=False,
    )

class order(models.Model):
    pending = 'PD'
    canceled = 'CA'
    completed = 'CM'

    order_status_choices = (
    (pending, 'Pending'),
    (canceled, 'Canceled'),
    (completed,'Completed'),
    )
    orderid = models.IntegerField(primary_key=True)
    orderdate = models.DateTimeField('Order Date', blank=False)
    employeeid = models.ForeignKey(employee,on_delete=models.CASCADE)
    customerid = models.ForeignKey(customer,on_delete=models.CASCADE)
    Items = models.ManyToManyField('Equipment', blank=True)
    orderstatus = models.CharField(
    'Order Status',
    max_length=50,
    choices=order_status_choices,
    default='Pending',
    blank=False,
    null=False
    )
    createddate = models.DateTimeField(default = datetime.now)

    # this will name the table appropirately in the db
    class Meta:
        db_table = 'order'

class orderdetails(models.Model):
    order = models.ForeignKey(order,on_delete=models.CASCADE)
    orderlineno = models.IntegerField('Order Line No', default=1, blank=False)
    equipmentid = models.IntegerField()# this needs to be a foreign key from equipment table
    equipmentqty = models.IntegerField('Equipment Qty', blank=False)
    salesamt = models.FloatField('Sales Amount',blank=False)
    createddate = models.DateTimeField(default = datetime.now)

    # this will name the table appropirately in the db
    class Meta:
        db_table = 'orderdetails'

class inventory(models.Model):
    inventoryid = models.IntegerField()
    inventorystatus = models.CharField(max_length=15)
    inventoryunits = models.IntegerField(blank=False)
    createddate = models.DateTimeField(default = datetime.now)

    class Meta:
        db_table = 'inventory'

class fees(models.Model):
    fee = models.IntegerField(primary_key=True)
    customer = models.ForeignKey(customer,on_delete=models.CASCADE)
    order = models.ForeignKey(order,on_delete=models.CASCADE)
    feeamt = models.FloatField('Fee Amount',blank=False)
    createddate = models.DateTimeField(default = datetime.now)

    class Meta:
        db_table = 'fees'

# Ian's classes.
# class Customer(models.Model):
#     customerid = models.IntegerField(primary_key=True)
#     firstname = models.CharField(max_length=100)
#     lastname = models.CharField(max_length=100)
#     phonenumber = models.CharField(max_length=10)
#     creditcard = models.CharField(max_length=16)
#     email = models.CharField(max_length=100)
#     createdate = models.DateTimeField()
#
# class Order(models.Model):
#     orderid = models.IntegerField(primary_key=True)
#     orderdate = models.DateTimeField()
#     employeeid = models.IntegerField()
#     customerid = models.IntegerField()
#     orderstatus = models.CharField(max_length=50)
#     createdate = models.DateTimeField()
#
# class OrderDetail(models.Model):
#     orderid = models.IntegerField()
#     orderlineno = models.IntegerField()
#     equipmentid = models.IntegerField()
#     equipmentqty = models.IntegerField()
#     salesamt = models.IntegerField()
#     createdate = models.DateTimeField()
#
# class Employee(models.Model):
#     employeeid = models.IntegerField(primary_key=True)
#     firstname = models.CharField(max_length=100)
#     lastname = models.CharField(max_length=100)
#     title = models.CharField(max_length=100)
#     reportsto = models.IntegerField()
#     createdate = models.DateTimeField()
#
# class Equipment(models.Model):
#     equipmentid = models.IntegerField(primary_key=True)
#     equipimage = models.ImageField(upload_to='images/')
#     equipdescr = models.CharField(max_length=500)
#     equipcategory =  models.CharField(max_length=100)
#     createdate = models.DateTimeField()
#
# class Inventory(models.Model):
#     equipmentid = models.IntegerField()
#     equipmentstatus = models.CharField(max_length=15)
#     equipmentunits = models.IntegerField()
#     createdate = models.DateTimeField()
#
# class Fee(models.Model):
#     feeid = models.IntegerField(primary_key=True)
#     customerid = models.IntegerField()
#     orderid = models.IntegerField()
#     feeamt = models.IntegerField()
#     feedate = models.DateTimeField()
#     createdate = models.DateTimeField()
